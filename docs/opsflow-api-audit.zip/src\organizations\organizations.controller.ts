import {
  Body,
  Controller,
  Delete,
  Get,
  NotFoundException,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';

import { OrganizationsService } from './organizations.service.js';

import { CreateOrganizationDto } from './dto/create-organization.dto.js';

import { UpdateOrganizationDto } from './dto/update-organization.dto.js';

import { OrganizationQueryDto } from './dto/organization-query.dto.js';

import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard.js';

import { CurrentUser } from '../auth/decorators/current-user.decorator.js';

import type { AuthenticatedUser } from '../auth/types/authenticated-user.type.js';

import { ParseObjectIdPipe } from '@nestjs/mongoose';

@UseGuards(JwtAuthGuard)
@Controller('organizations')
export class OrganizationsController {
  constructor(
    private readonly organizationService: OrganizationsService,
  ) {}

  @Post()
  async create(
    @Body() dto: CreateOrganizationDto,

    @CurrentUser()
    user: AuthenticatedUser,
  ) {
    return this.organizationService.create(
      dto.name,
      dto.slug,
      user.userId,
    );
  }

  /**
   * Returns the authenticated user's organizations.
   *
   * Query parameters control search, filtering,
   * sorting, and pagination.
   */
  @Get()
  async findAll(
    @CurrentUser()
    user: AuthenticatedUser,

    @Query()
    query: OrganizationQueryDto,
  ) {
    return this.organizationService.findAll(
      user.userId,
      query,
    );
  }

  @Get('test-error')
  testError() {
    throw new NotFoundException(
      'Test organization not found',
    );
  }

  @Get(':id')
  async findOne(
    @Param(
      'id',
      ParseObjectIdPipe,
    )
    id: string,

    @CurrentUser()
    user: AuthenticatedUser,
  ) {
    return this.organizationService.findOne(
      id,
      user.userId,
    );
  }

  @Patch(':id')
  async update(
    @Param(
      'id',
      ParseObjectIdPipe,
    )
    id: string,

    @Body()
    dto: UpdateOrganizationDto,

    @CurrentUser()
    user: AuthenticatedUser,
  ) {
    return this.organizationService.update(
      id,
      user.userId,
      dto,
    );
  }

  @Delete(':id')
  async remove(
    @Param(
      'id',
      ParseObjectIdPipe,
    )
    id: string,

    @CurrentUser()
    user: AuthenticatedUser,
  ) {
    return this.organizationService.remove(
      id,
      user.userId,
    );
  }
}