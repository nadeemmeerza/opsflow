import {
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';

import { InjectModel } from '@nestjs/mongoose';

import {
  Organization,
  OrganizationDocument,
} from './schemas/organization.schema.js';

import { Model, Types } from 'mongoose';

import {
  OrganizationMember,
  OrganizationMemberDocument,
} from '../organization-members/schemas/organization-member.schema.js';

import { AuditService } from '../audit/audit.service.js';

import { OrganizationQueryDto } from './dto/organization-query.dto.js';

@Injectable()
export class OrganizationsService {
  constructor(
    @InjectModel(Organization.name)
    private readonly organizationModel: Model<OrganizationDocument>,

    @InjectModel(OrganizationMember.name)
    private readonly organizationMemberModel: Model<OrganizationMemberDocument>,

    private readonly auditService: AuditService,
  ) {}

  async create(
    name: string,
    slug: string,
    ownerId: string,
  ) {
    const normalizedSlug =
      slug.trim().toLowerCase();

    try {
      const organization =
        new this.organizationModel({
          name: name.trim(),
          slug: normalizedSlug,
          ownerId: new Types.ObjectId(ownerId),
        });

      const savedOrganization =
        await organization.save();

      await this.organizationMemberModel.create({
        organizationId: savedOrganization._id,
        userId: new Types.ObjectId(ownerId),
        role: 'owner',
      });

      await this.auditService.log({
        organizationId:
          savedOrganization._id.toString(),

        userId: ownerId,

        action: 'CREATE',

        entity: 'Organization',

        entityId:
          savedOrganization._id.toString(),

        metadata: {
          name: savedOrganization.name,
          slug: savedOrganization.slug,
        },
      });

      return savedOrganization;
    } catch (error: any) {
      if (error?.code === 11000) {
        throw new ConflictException(
          'An organization with this slug already exists',
        );
      }

      throw error;
    }
  }

  /**
   * Returns a paginated organization list owned by
   * the authenticated user.
   *
   * Search, filtering, sorting, and pagination are performed
   * by MongoDB instead of loading the complete organization
   * collection into application memory.
   */
  async findAll(
    ownerId: string,
    query: OrganizationQueryDto,
  ) {
    const ownerObjectId =
      new Types.ObjectId(ownerId);

    const page = query.page ?? 1;
    const limit = query.limit ?? 10;

    const filter: Record<string, any> = {
      ownerId: ownerObjectId,
    };

    /*
     * Apply the optional status filter.
     */
    if (query.status) {
      filter.status = query.status;
    }

    /*
     * Escape the search text before creating the regular
     * expression so characters such as "." or "*" cannot
     * accidentally change the search expression.
     */
    if (query.search?.trim()) {
      const searchRegex = new RegExp(
        query.search
          .trim()
          .replace(/[.*+?^${}()|[\]\\]/g, '\\$&'),
        'i',
      );

      filter.$or = [
        {
          name: searchRegex,
        },
        {
          slug: searchRegex,
        },
      ];
    }

    const sortBy =
      query.sortBy ?? 'createdAt';

    const sortOrder =
      query.sortOrder ?? 'desc';

    const sortDirection =
      sortOrder === 'asc' ? 1 : -1;

    const skip = (page - 1) * limit;

    /*
     * Fetch the current page and total count in parallel.
     *
     * The frontend needs both values to render the
     * organization cards and pagination controls.
     */
    const [items, total] =
      await Promise.all([
        this.organizationModel
          .find(filter)
          .sort({
            [sortBy]: sortDirection,
          })
          .skip(skip)
          .limit(limit)
          .exec(),

        this.organizationModel.countDocuments(
          filter,
        ),
      ]);

    return {
      items,

      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(
          total / limit,
        ),
      },
    };
  }

  async findOne(
    id: string,
    ownerId: string,
  ) {
    const organization =
      await this.organizationModel
        .findOne({
          _id: id,
          ownerId:
            new Types.ObjectId(ownerId),
        })
        .exec();

    if (!organization) {
      throw new NotFoundException(
        'Organization not found',
      );
    }

    return organization;
  }

  async update(
    id: string,
    ownerId: string,
    data: {
      name?: string;
      slug?: string;
      status?: 'active' | 'suspended';
    },
  ) {
    const updateData = {
      ...data,

      ...(data.name !== undefined && {
        name: data.name.trim(),
      }),

      ...(data.slug !== undefined && {
        slug: data.slug
          .trim()
          .toLowerCase(),
      }),
    };

    const organization =
      await this.organizationModel
        .findOneAndUpdate(
          {
            _id: id,
            ownerId:
              new Types.ObjectId(ownerId),
          },
          {
            $set: updateData,
          },
          {
            new: true,
            runValidators: true,
          },
        )
        .exec();

    if (!organization) {
      throw new NotFoundException(
        'Organization not found',
      );
    }

    await this.auditService.log({
      organizationId: id,

      userId: ownerId,

      action: 'UPDATE',

      entity: 'Organization',

      entityId:
        organization._id.toString(),

      metadata: {
        updatedFields:
          Object.keys(updateData),
      },
    });

    return organization;
  }

  async remove(
    id: string,
    ownerId: string,
  ) {
    const organization =
      await this.organizationModel
        .findOneAndDelete({
          _id: id,
          ownerId:
            new Types.ObjectId(ownerId),
        })
        .exec();

    if (!organization) {
      throw new NotFoundException(
        'Organization not found',
      );
    }

    await this.auditService.log({
      organizationId: id,

      userId: ownerId,

      action: 'DELETE',

      entity: 'Organization',

      entityId:
        organization._id.toString(),

      metadata: {
        name: organization.name,
        slug: organization.slug,
      },
    });

    return {
      success: true,
      message:
        'Organization deleted successfully',
    };
  }
}